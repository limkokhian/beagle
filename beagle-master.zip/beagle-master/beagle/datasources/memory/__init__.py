from .windows_rekall import WindowsMemory  # noqa
