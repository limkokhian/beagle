import * as React from 'react';

const Home: React.StatelessComponent<{}> = () => {
    return (
        <div>
            {/* <GraphPage /> */}
            Home
        </div>
    );
};

export default Home;
