export default interface Node {
    id: number;
    properties: object;
    label: string;
    color: string;
    _display: string;
    _node_type: string;
}
