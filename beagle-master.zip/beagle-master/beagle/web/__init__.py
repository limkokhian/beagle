from .server import create_app  # noqa: F401

