.. Beagle documentation master file, created by
   sphinx-quickstart on Wed Mar 20 08:24:08 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: beagle.rst
