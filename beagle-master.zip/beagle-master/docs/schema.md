## Data Schema

The following provides examples of the various fields used by each of beagle's supported edges. 

TODO
