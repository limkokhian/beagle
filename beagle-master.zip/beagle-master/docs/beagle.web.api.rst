beagle.web.api package
======================

Submodules
----------

beagle.web.api.models module
----------------------------

.. automodule:: beagle.web.api.models
    :members:
    :undoc-members:
    :show-inheritance:

beagle.web.api.views module
---------------------------

.. automodule:: beagle.web.api.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: beagle.web.api
    :members:
    :undoc-members:
    :show-inheritance:
