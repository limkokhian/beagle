.. include:: beagle.rst
